import { MessageCircle, Plus } from 'lucide-react'
import { cn } from '@/lib/utils'
import { btnOutline, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

export function Faq({ faq, whatsapp }: { faq: SiteContent['faq']; whatsapp: string }) {
  return (
    <section className="border-t border-border bg-card py-20 md:py-28">
      <div className={cn(container, 'grid gap-12 lg:grid-cols-[2fr_3fr]')}>
        <div className="flex flex-col gap-5">
          <p className="eyebrow">{faq.eyebrow}</p>
          <h2 className="text-4xl md:text-5xl">{faq.title}</h2>
          <p className="leading-relaxed text-muted-foreground">{faq.description}</p>
          <a href={whatsapp} target="_blank" rel="noreferrer" className={cn(btnOutline, 'self-start')}>
            <MessageCircle className="size-4" aria-hidden="true" />
            Preguntar por WhatsApp
          </a>
        </div>
        <div className="flex flex-col">
          {faq.items.map((item) => (
            <details key={item.q} className="group border-b border-border py-6">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 font-serif text-xl [&::-webkit-details-marker]:hidden">
                {item.q}
                <Plus className="size-5 shrink-0 text-accent transition-transform group-open:rotate-45" aria-hidden="true" />
              </summary>
              <p className="pt-4 leading-relaxed text-muted-foreground">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
