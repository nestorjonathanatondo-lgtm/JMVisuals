import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import { btnLight, btnOutlineDark, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

export function Vascular({ vascular }: { vascular: SiteContent['vascular'] }) {
  if (!vascular.enabled) return null
  return (
    <section className="bg-dark py-20 text-dark-foreground md:py-28">
      <div className={cn(container, 'grid items-center gap-12 lg:grid-cols-2')}>
        <div className="flex flex-col gap-6">
          <p className="eyebrow text-accent-light">{vascular.eyebrow}</p>
          <h2 className="text-balance text-4xl md:text-5xl">
            {vascular.titleBefore} <em className="text-accent-light">{vascular.titleAccent}</em>
          </h2>
          <p className="max-w-lg leading-relaxed text-dark-foreground/75">{vascular.description}</p>
          <div className="flex flex-wrap gap-3">
            <Link href={`/agendar?servicio=${vascular.treatmentSlug}`} className={btnLight}>
              {vascular.ctaLabel}
            </Link>
            <Link href={`/tratamientos/${vascular.treatmentSlug}`} className={btnOutlineDark}>
              Conocer más
            </Link>
          </div>
        </div>
        <div className="relative mx-auto aspect-[3/4] w-full max-w-sm overflow-hidden rounded-4xl bg-dark-foreground/10 shadow-2xl">
          {vascular.video ? (
            <video
              src={vascular.video}
              poster={vascular.image || undefined}
              autoPlay
              muted
              loop
              playsInline
              aria-label={vascular.titleBefore + ' ' + vascular.titleAccent}
              className="absolute inset-0 size-full object-cover"
            />
          ) : (
            vascular.image && (
              <Image src={vascular.image || '/placeholder.svg'} alt={vascular.eyebrow} fill sizes="(min-width: 1024px) 30vw, 90vw" className="object-cover" />
            )
          )}
        </div>
      </div>
    </section>
  )
}
