import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'
import { ResultsGallery } from '../results-gallery'

export function ResultsSection({ results }: { results: SiteContent['results'] }) {
  return (
    <section id="resultados" className="border-t border-border bg-card py-20 md:py-28">
      <div className={cn(container, 'flex flex-col gap-10')}>
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="flex max-w-xl flex-col gap-4">
            <p className="eyebrow">{results.eyebrow}</p>
            <h2 className="text-4xl md:text-5xl">{results.title}</h2>
            <p className="leading-relaxed text-muted-foreground">{results.description}</p>
          </div>
          <Link
            href="/resultados"
            className="inline-flex h-11 shrink-0 items-center gap-2 self-start rounded-full border border-accent-light/70 px-5 text-xs font-semibold uppercase tracking-[0.14em] hover:bg-background md:self-auto"
          >
            Ver galería completa
            <ArrowUpRight className="size-3.5" aria-hidden="true" />
          </Link>
        </div>
        <ResultsGallery items={results.items} />
        <p className="text-center text-xs text-muted-foreground">{results.disclaimer}</p>
      </div>
    </section>
  )
}
