import { Clock, MapPin, Navigation, Phone } from 'lucide-react'
import { mapsEmbed, mapsLink } from '@/lib/content'
import { cn } from '@/lib/utils'
import { btnOutline, btnPrimary, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

export function Location({ content }: { content: SiteContent }) {
  const { contact, location } = content
  return (
    <section className="py-20 md:py-28">
      <div className={cn(container, 'grid items-stretch gap-10 lg:grid-cols-2')}>
        <div className="flex flex-col gap-8">
          <div className="flex flex-col gap-4">
            <p className="eyebrow">{location.eyebrow}</p>
            <h2 className="text-balance text-4xl md:text-5xl">{location.title}</h2>
          </div>
          <dl className="flex flex-col gap-6">
            <div className="flex gap-4">
              <MapPin className="mt-1 size-5 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <dt className="font-semibold">Dirección</dt>
                <dd className="leading-relaxed text-muted-foreground">{contact.address} · {contact.city}</dd>
              </div>
            </div>
            <div className="flex gap-4">
              <Clock className="mt-1 size-5 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <dt className="font-semibold">Horario</dt>
                <dd className="leading-relaxed text-muted-foreground">{contact.hoursLong}</dd>
              </div>
            </div>
            <div className="flex gap-4">
              <Phone className="mt-1 size-5 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <dt className="font-semibold">Teléfono</dt>
                <dd className="text-muted-foreground">
                  <a href={`tel:${contact.phone}`} className="hover:text-accent">{contact.phoneDisplay}</a>
                </dd>
              </div>
            </div>
          </dl>
          <div className="flex flex-wrap gap-3">
            <a href={mapsLink(content)} target="_blank" rel="noreferrer" className={btnPrimary}>
              <Navigation className="size-4" aria-hidden="true" />
              Cómo llegar
            </a>
            <a href={`tel:${contact.phone}`} className={btnOutline}>
              <Phone className="size-4" aria-hidden="true" />
              Llamar
            </a>
          </div>
        </div>
        <div className="min-h-80 overflow-hidden rounded-4xl border border-border bg-muted">
          <iframe
            title="Mapa de ubicación del consultorio"
            src={mapsEmbed(content)}
            className="size-full min-h-80"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  )
}
