import { HeartPulse, ShieldCheck, Sparkles, UserRound } from 'lucide-react'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

const ICONS = [UserRound, ShieldCheck, Sparkles, HeartPulse]

export function Pillars({ pillars }: { pillars: SiteContent['pillars'] }) {
  return (
    <section className="border-y border-border bg-card py-20 md:py-28">
      <div className={cn(container, 'flex flex-col items-center gap-14')}>
        <div className="flex max-w-2xl flex-col items-center gap-4 text-center">
          <p className="eyebrow">{pillars.eyebrow}</p>
          <h2 className="text-balance text-4xl md:text-5xl">{pillars.title}</h2>
        </div>
        <ul className="grid w-full gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.items.map((item, i) => {
            const Icon = ICONS[i % ICONS.length]
            return (
              <li key={item.title} className="flex flex-col gap-4 rounded-3xl border border-border bg-background p-7">
                <span className="flex size-11 items-center justify-center rounded-full border border-accent-light/50 text-accent">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <h3 className="text-xl">{item.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{item.text}</p>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
