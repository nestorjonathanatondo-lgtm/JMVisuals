import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'
import { TreatmentCard } from '../treatment-card'

export function TreatmentsPreview({ content }: { content: SiteContent }) {
  const { treatmentsSection, treatments, categories } = content
  const featured = treatments.filter((t) => t.featured).slice(0, 6)
  const list = featured.length ? featured : treatments.slice(0, 6)
  return (
    <section className="py-20 md:py-28">
      <div className={cn(container, 'flex flex-col gap-10')}>
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="flex max-w-xl flex-col gap-4">
            <p className="eyebrow">{treatmentsSection.eyebrow}</p>
            <h2 className="text-balance text-4xl md:text-5xl">{treatmentsSection.title}</h2>
          </div>
          <Link
            href="/tratamientos"
            className="inline-flex h-11 shrink-0 items-center gap-2 self-start rounded-full border border-accent-light/70 px-5 text-xs font-semibold uppercase tracking-[0.14em] hover:bg-card md:self-auto"
          >
            {treatmentsSection.ctaLabel}
            <ArrowUpRight className="size-3.5" aria-hidden="true" />
          </Link>
        </div>
        <ul className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <li key={category}>
              <Link
                href={`/tratamientos?categoria=${encodeURIComponent(category)}`}
                className="inline-flex rounded-full bg-muted px-4 py-2 text-sm text-foreground/80 transition-colors hover:bg-primary hover:text-primary-foreground"
              >
                {category}
              </Link>
            </li>
          ))}
        </ul>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((treatment) => (
            <TreatmentCard key={treatment.slug} treatment={treatment} />
          ))}
        </div>
      </div>
    </section>
  )
}
