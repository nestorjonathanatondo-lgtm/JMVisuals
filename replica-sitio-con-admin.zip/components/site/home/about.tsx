import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Check, MessageCircle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { btnOutline, btnPrimary, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

export function About({ about, whatsapp }: { about: SiteContent['about']; whatsapp: string }) {
  return (
    <section id="sobre" className="scroll-mt-20 border-y border-border bg-card py-20 md:py-28">
      <div className={cn(container, 'grid items-center gap-12 lg:grid-cols-[2fr_3fr] lg:gap-20')}>
        <div className="relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-4xl bg-muted">
          <Image
            src={about.image || '/placeholder.svg'}
            alt="Retrato de la Dra. Nallely Mellado"
            fill
            sizes="(min-width: 1024px) 35vw, 90vw"
            className="object-cover"
          />
        </div>
        <div className="flex flex-col gap-6">
          <p className="eyebrow">{about.eyebrow}</p>
          <h2 className="text-balance text-4xl md:text-5xl">{about.title}</h2>
          {about.quote && (
            <blockquote className="border-l border-accent-light pl-5 font-serif text-xl italic text-accent">
              {`“${about.quote}”`}
            </blockquote>
          )}
          <p className="leading-relaxed text-muted-foreground">{about.text}</p>
          <ul className="grid gap-3 sm:grid-cols-2">
            {about.credentials.map((item) => (
              <li key={item} className="flex items-center gap-3 text-sm">
                <span className="flex size-6 items-center justify-center rounded-full bg-muted text-accent">
                  <Check className="size-3.5" aria-hidden="true" />
                </span>
                {item}
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link href="/agendar" className={btnPrimary}>
              Agendar con la Dra.
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <a href={whatsapp} target="_blank" rel="noreferrer" className={btnOutline}>
              <MessageCircle className="size-4" aria-hidden="true" />
              WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
