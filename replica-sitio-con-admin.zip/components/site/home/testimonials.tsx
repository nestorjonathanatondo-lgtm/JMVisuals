import { Star } from 'lucide-react'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

export function Testimonials({ testimonials }: { testimonials: SiteContent['testimonials'] }) {
  return (
    <section className="py-20 md:py-28">
      <div className={cn(container, 'flex flex-col items-center gap-14')}>
        <div className="flex max-w-2xl flex-col items-center gap-4 text-center">
          <p className="eyebrow">{testimonials.eyebrow}</p>
          <h2 className="text-balance text-4xl md:text-5xl">{testimonials.title}</h2>
        </div>
        <ul className="grid w-full gap-5 md:grid-cols-3">
          {testimonials.items.map((item) => (
            <li key={item.name + item.quote.slice(0, 12)} className="flex flex-col gap-6 rounded-3xl border border-border bg-card p-7">
              <div className="flex gap-1 text-accent-light" aria-label={`${item.rating} de 5 estrellas`}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={cn('size-4', i < item.rating ? 'fill-current' : 'opacity-30')} aria-hidden="true" />
                ))}
              </div>
              <blockquote className="font-serif text-xl italic leading-snug">{`“${item.quote}”`}</blockquote>
              <p className="mt-auto border-t border-border pt-4 text-sm">
                <span className="font-semibold">{item.name}</span>
                <span className="text-muted-foreground"> · {item.treatment}</span>
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
