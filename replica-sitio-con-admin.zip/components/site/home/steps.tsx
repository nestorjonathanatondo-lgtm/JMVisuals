import Link from 'next/link'
import { ArrowRight, CalendarDays, MessageCircle, Sparkles, Stethoscope } from 'lucide-react'
import { cn } from '@/lib/utils'
import { btnPrimary, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'

const ICONS = [MessageCircle, CalendarDays, Stethoscope, Sparkles]

export function Steps({ steps }: { steps: SiteContent['steps'] }) {
  return (
    <section className="py-20 md:py-28">
      <div className={cn(container, 'flex flex-col items-center gap-14')}>
        <div className="flex flex-col items-center gap-4 text-center">
          <p className="eyebrow">{steps.eyebrow}</p>
          <h2 className="text-balance text-4xl md:text-5xl">{steps.title}</h2>
        </div>
        <ol className="grid w-full gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {steps.items.map((step, i) => {
            const Icon = ICONS[i % ICONS.length]
            return (
              <li key={step.title} className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-7">
                <div className="flex items-start justify-between">
                  <span className="font-serif text-4xl text-accent-light">{String(i + 1).padStart(2, '0')}</span>
                  <Icon className="size-5 text-accent" aria-hidden="true" />
                </div>
                <h3 className="text-xl">{step.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{step.text}</p>
              </li>
            )
          })}
        </ol>
        <Link href="/agendar" className={btnPrimary}>
          {steps.ctaLabel}
          <ArrowRight className="size-4" aria-hidden="true" />
        </Link>
      </div>
    </section>
  )
}
