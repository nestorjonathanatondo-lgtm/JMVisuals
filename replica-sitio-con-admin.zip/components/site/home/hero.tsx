import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, ShieldCheck } from 'lucide-react'
import { cn } from '@/lib/utils'
import { btnOutline, btnPrimary, container } from '@/lib/ui'
import type { SiteContent } from '@/lib/types'
import { InlineBold } from '../rich-text'

export function Hero({ hero }: { hero: SiteContent['hero'] }) {
  return (
    <section className={cn(container, 'grid items-center gap-12 pb-20 pt-12 lg:grid-cols-2 lg:pt-16')}>
      <div className="flex animate-rise flex-col gap-7">
        <p className="eyebrow mt-3">{hero.eyebrow}</p>
        <h1 className="max-w-2xl text-balance text-[2.45rem] leading-[1.05] md:text-6xl xl:text-[4.6rem]">
          {hero.titleBefore} <em className="text-accent">{hero.titleAccent}</em> {hero.titleAfter}
        </h1>
        <p className="max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
          <InlineBold text={hero.description} />
        </p>
        <div className="flex flex-wrap gap-3">
          <Link href="/agendar" className={btnPrimary}>
            {hero.primaryCta}
            <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
          <Link href="/tratamientos" className={btnOutline}>
            {hero.secondaryCta}
          </Link>
        </div>
        {hero.stats.length > 0 && (
          <dl className="mt-4 flex max-w-lg flex-wrap gap-x-14 gap-y-6 border-t border-border pt-7">
            {hero.stats.map((stat) => (
              <div key={stat.label} className="flex flex-col-reverse gap-1">
                <dt className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{stat.label}</dt>
                <dd className="font-serif text-3xl">{stat.value}</dd>
              </div>
            ))}
          </dl>
        )}
      </div>

      <div className="relative animate-rise [animation-delay:150ms]">
        <div className="relative aspect-[4/5] overflow-hidden rounded-4xl bg-muted shadow-2xl">
          <Image
            src={hero.image || '/placeholder.svg'}
            alt={hero.imageAlt}
            fill
            priority
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-cover"
          />
          {hero.badge && (
            <span className="absolute right-5 top-5 flex items-center gap-2 rounded-full bg-card/90 px-4 py-2 text-sm shadow backdrop-blur">
              <ShieldCheck className="size-4 text-accent" aria-hidden="true" />
              {hero.badge}
            </span>
          )}
          <div className="absolute bottom-5 left-5 max-w-60 rounded-2xl bg-card/95 p-4 shadow-lg backdrop-blur">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-accent">{hero.locationEyebrow}</p>
            <p className="mt-1 font-serif text-lg leading-snug">{hero.locationTitle}</p>
          </div>
        </div>
      </div>
    </section>
  )
}
