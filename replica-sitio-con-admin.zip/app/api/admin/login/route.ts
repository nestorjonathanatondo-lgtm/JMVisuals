import { NextResponse } from 'next/server'
import { ADMIN_COOKIE, checkPassword, createSessionToken } from '@/lib/auth'

const attempts = new Map<string, { count: number; until: number }>()

export async function POST(request: Request) {
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local'
  const record = attempts.get(ip)
  if (record && record.until > Date.now() && record.count >= 5) {
    return NextResponse.json({ error: 'Demasiados intentos. Espera unos minutos.' }, { status: 429 })
  }

  const body = await request.json().catch(() => ({}))
  if (!checkPassword(body.password)) {
    const next = record && record.until > Date.now() ? record.count + 1 : 1
    attempts.set(ip, { count: next, until: Date.now() + 5 * 60 * 1000 })
    return NextResponse.json({ error: 'Contraseña incorrecta' }, { status: 401 })
  }

  attempts.delete(ip)
  const { token, maxAge } = createSessionToken()
  const res = NextResponse.json({ ok: true })
  res.cookies.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge,
  })
  return res
}
