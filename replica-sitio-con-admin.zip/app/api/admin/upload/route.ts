import { NextResponse } from 'next/server'
import { isAdmin } from '@/lib/auth'
import { saveUpload } from '@/lib/storage'

const MAX_BYTES = 25 * 1024 * 1024
const ALLOWED = /^(image\/(png|jpe?g|webp|gif|svg\+xml|avif|x-icon|vnd\.microsoft\.icon)|video\/(mp4|webm))$/

export async function POST(request: Request) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
  const form = await request.formData().catch(() => null)
  const file = form?.get('file')
  if (!(file instanceof File)) return NextResponse.json({ error: 'Archivo no recibido' }, { status: 400 })
  if (!ALLOWED.test(file.type)) return NextResponse.json({ error: 'Formato no permitido' }, { status: 400 })
  if (file.size > MAX_BYTES) return NextResponse.json({ error: 'El archivo supera 25 MB' }, { status: 400 })
  try {
    const url = await saveUpload(file)
    return NextResponse.json({ url })
  } catch (error) {
    console.error('[admin] upload failed', error)
    return NextResponse.json({ error: 'No se pudo subir el archivo' }, { status: 500 })
  }
}
