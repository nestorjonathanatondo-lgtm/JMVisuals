import { NextResponse } from 'next/server'
import { isAdmin } from '@/lib/auth'
import { reindexTreatments } from '@/lib/algolia'

export async function POST() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'No autorizado.' }, { status: 401 })
  try {
    const result = await reindexTreatments()
    return NextResponse.json({ ok: true, result })
  } catch {
    return NextResponse.json({ error: 'No se pudo actualizar el índice.' }, { status: 503 })
  }
}
