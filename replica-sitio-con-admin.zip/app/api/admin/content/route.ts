import { NextResponse } from 'next/server'
import { isAdmin } from '@/lib/auth'
import { getContent, mergeContent, saveContent } from '@/lib/content'
import { defaultContent } from '@/lib/default-content'
import type { SiteContent } from '@/lib/types'

const unauthorized = () => NextResponse.json({ error: 'No autorizado' }, { status: 401 })

export async function GET() {
  if (!(await isAdmin())) return unauthorized()
  return NextResponse.json(await getContent())
}

export async function PUT(request: Request) {
  if (!(await isAdmin())) return unauthorized()
  const body = (await request.json().catch(() => null)) as Partial<SiteContent> | null
  if (!body || typeof body !== 'object') return NextResponse.json({ error: 'Contenido inválido' }, { status: 400 })

  const allowed = Object.keys(defaultContent) as (keyof SiteContent)[]
  const clean = Object.fromEntries(allowed.filter((k) => k in body).map((k) => [k, body[k]])) as Partial<SiteContent>
  const merged = mergeContent(clean)

  const slugs = new Set<string>()
  for (const t of merged.treatments) {
    if (!t.slug || !/^[a-z0-9-]+$/.test(t.slug)) {
      return NextResponse.json({ error: `El identificador de «${t.name}» solo puede tener minúsculas, números y guiones.` }, { status: 400 })
    }
    if (slugs.has(t.slug)) return NextResponse.json({ error: `Identificador duplicado: ${t.slug}` }, { status: 400 })
    slugs.add(t.slug)
  }

  try {
    await saveContent(merged)
  } catch (error) {
    console.error('[admin] save failed', error)
    return NextResponse.json(
      { error: 'No se pudo guardar. En producción conecta Vercel Blob para habilitar el guardado.' },
      { status: 500 },
    )
  }
  return NextResponse.json(merged)
}

export async function DELETE() {
  if (!(await isAdmin())) return unauthorized()
  await saveContent(structuredClone(defaultContent))
  return NextResponse.json(defaultContent)
}
