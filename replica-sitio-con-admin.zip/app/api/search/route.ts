import { NextResponse } from 'next/server'
import { searchTreatments } from '@/lib/algolia'

export async function GET(request: Request) {
  const query = new URL(request.url).searchParams.get('q')?.trim() || ''
  if (!query) return NextResponse.json({ hits: [] })
  try {
    const result = await searchTreatments(query)
    return NextResponse.json({ hits: result.hits ?? [] })
  } catch {
    return NextResponse.json({ error: 'No se pudo realizar la búsqueda.' }, { status: 503 })
  }
}
