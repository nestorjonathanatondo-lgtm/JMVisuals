import { NextResponse } from 'next/server'
import { digitsOnly, listAppointments, updateAppointment } from '@/lib/appointments'

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}))
  const folio = typeof body.folio === 'string' ? body.folio.trim().toUpperCase() : ''
  const phone = typeof body.phone === 'string' ? digitsOnly(body.phone) : ''
  if (!folio || phone.length < 7) return NextResponse.json({ error: 'Ingresa tu folio y teléfono.' }, { status: 400 })

  const items = await listAppointments()
  const match = items.find((a) => a.folio === folio && digitsOnly(a.data.phone ?? '').endsWith(phone.slice(-10)))
  if (!match) return NextResponse.json({ error: 'No encontramos una cita con esos datos.' }, { status: 404 })

  let appointment = match
  if (body.action === 'cancel' && (match.status === 'pendiente' || match.status === 'confirmada')) {
    appointment = (await updateAppointment(folio, { status: 'cancelada' })) ?? match
  }

  return NextResponse.json({
    appointment: {
      folio: appointment.folio,
      treatmentName: appointment.treatmentName,
      date: appointment.date,
      time: appointment.time,
      status: appointment.status,
    },
  })
}
