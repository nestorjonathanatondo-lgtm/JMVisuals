import { NextResponse } from 'next/server'
import { createAppointment, digitsOnly, listAppointments } from '@/lib/appointments'
import { getContent } from '@/lib/content'
import { parseISODate, slotsForDay, toISODate } from '@/lib/schedule'

export async function POST(request: Request) {
  let body: { treatmentSlug?: unknown; date?: unknown; time?: unknown; data?: unknown; accepted?: unknown }
  try {
    body = await request.json()
  } catch {
    return NextResponse.json({ error: 'Solicitud inválida' }, { status: 400 })
  }

  const content = await getContent()
  const { booking } = content
  const treatment = content.treatments.find((t) => t.slug === body.treatmentSlug)
  if (!treatment) return NextResponse.json({ error: 'Selecciona un tratamiento válido.' }, { status: 400 })
  if (body.accepted !== true) return NextResponse.json({ error: 'Debes aceptar el aviso de privacidad.' }, { status: 400 })

  const date = typeof body.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(body.date) ? body.date : null
  const time = typeof body.time === 'string' && /^\d{2}:\d{2}$/.test(body.time) ? body.time : null
  if (!date || !time) return NextResponse.json({ error: 'Selecciona fecha y hora.' }, { status: 400 })

  const day = parseISODate(date)
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const limit = new Date(today)
  limit.setDate(limit.getDate() + (booking.maxDaysAhead || 60))
  if (toISODate(day) !== date || day < today || day > limit) {
    return NextResponse.json({ error: 'La fecha seleccionada no está disponible.' }, { status: 400 })
  }
  if (!slotsForDay(booking.schedule[day.getDay()], booking.slotMinutes).includes(time)) {
    return NextResponse.json({ error: 'El horario seleccionado no está disponible.' }, { status: 400 })
  }

  const raw = body.data && typeof body.data === 'object' ? (body.data as Record<string, unknown>) : {}
  const data: Record<string, string> = {}
  for (const field of booking.fields) {
    const value = typeof raw[field.id] === 'string' ? (raw[field.id] as string).trim().slice(0, field.type === 'textarea' ? 1000 : 200) : ''
    if (field.required && !value) return NextResponse.json({ error: `Completa el campo «${field.label}».` }, { status: 400 })
    if (value && field.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return NextResponse.json({ error: 'Revisa tu correo electrónico.' }, { status: 400 })
    }
    if (value && field.type === 'tel' && digitsOnly(value).length < 10) {
      return NextResponse.json({ error: 'Ingresa un teléfono de al menos 10 dígitos.' }, { status: 400 })
    }
    if (value && (field.type === 'select' || field.type === 'choice') && !field.options.includes(value)) {
      return NextResponse.json({ error: `Opción inválida en «${field.label}».` }, { status: 400 })
    }
    if (value) data[field.id] = value
  }

  const existing = await listAppointments()
  const clash = existing.some((a) => a.date === date && a.time === time && a.status !== 'cancelada')
  if (clash) return NextResponse.json({ error: 'Ese horario acaba de ocuparse. Elige otro, por favor.' }, { status: 409 })

  const appointment = await createAppointment({
    treatmentSlug: treatment.slug,
    treatmentName: treatment.name,
    date,
    time,
    data,
  })

  return NextResponse.json({
    appointment: {
      folio: appointment.folio,
      treatmentName: appointment.treatmentName,
      date: appointment.date,
      time: appointment.time,
      status: appointment.status,
    },
  })
}
