import { NextResponse } from 'next/server'
import { listAppointments } from '@/lib/appointments'

export async function GET(request: Request) {
  const date = new URL(request.url).searchParams.get('date') ?? ''
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return NextResponse.json({ taken: [] })
  const items = await listAppointments()
  const taken = items.filter((a) => a.date === date && a.status !== 'cancelada').map((a) => a.time)
  return NextResponse.json({ taken }, { headers: { 'Cache-Control': 'no-store' } })
}
