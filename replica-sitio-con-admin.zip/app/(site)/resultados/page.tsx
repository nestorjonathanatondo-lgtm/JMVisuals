import type { Metadata } from 'next'
import { CtaBand } from '@/components/site/cta-band'
import { Vascular } from '@/components/site/home/vascular'
import { PageIntro } from '@/components/site/page-intro'
import { ResultsGallery } from '@/components/site/results-gallery'
import { getContent, whatsappLink } from '@/lib/content'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'

export const metadata: Metadata = { title: 'Resultados antes y después' }

export default async function ResultsPage() {
  const content = await getContent()
  return (
    <>
      <PageIntro eyebrow={content.results.eyebrow} title="Resultados reales, naturales y armónicos">
        <p>Cada caso es único. Toca una imagen para verla en grande.</p>
      </PageIntro>
      <div className={cn(container, 'flex flex-col gap-8 pb-20')}>
        <ResultsGallery items={content.results.items} />
        <p className="text-center text-xs text-muted-foreground">{content.results.disclaimer}</p>
      </div>
      <Vascular vascular={content.vascular} />
      <div className="pt-20 md:pt-28">
        <CtaBand cta={content.cta} whatsapp={whatsappLink(content)} />
      </div>
    </>
  )
}
