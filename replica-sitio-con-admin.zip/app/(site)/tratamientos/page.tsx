import type { Metadata } from 'next'
import Link from 'next/link'
import { PageIntro } from '@/components/site/page-intro'
import { TreatmentCard } from '@/components/site/treatment-card'
import { TreatmentSearch } from '@/components/site/treatment-search'
import { getContent } from '@/lib/content'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'

export const metadata: Metadata = { title: 'Tratamientos' }

export default async function TreatmentsPage({ searchParams }: { searchParams: Promise<{ categoria?: string }> }) {
  const { categoria } = await searchParams
  const content = await getContent()
  const active = categoria && content.categories.includes(categoria) ? categoria : null
  const list = active ? content.treatments.filter((t) => t.category === active) : content.treatments

  const chip = (selected: boolean) =>
    cn(
      'inline-flex rounded-full px-4 py-2 text-sm transition-colors',
      selected ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground/80 hover:bg-border',
    )

  return (
    <>
      <PageIntro eyebrow="Tratamientos" title="Protocolos de medicina estética de alta precisión">
        <p>
          {content.treatmentsSection.description}{' '}
          {content.contact.catalogUrl && (
            <a href={content.contact.catalogUrl} target="_blank" rel="noreferrer" className="text-accent underline underline-offset-4">
              Ver catálogo digital
            </a>
          )}
        </p>
      </PageIntro>
      <div className={cn(container, 'flex flex-col gap-10 pb-24')}>
        <TreatmentSearch />
        <nav aria-label="Categorías">
          <ul className="flex flex-wrap gap-2">
            <li>
              <Link href="/tratamientos" className={chip(!active)} aria-current={!active ? 'page' : undefined}>
                Todos
              </Link>
            </li>
            {content.categories.map((category) => (
              <li key={category}>
                <Link
                  href={`/tratamientos?categoria=${encodeURIComponent(category)}`}
                  className={chip(active === category)}
                  aria-current={active === category ? 'page' : undefined}
                >
                  {category}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <p className="text-sm text-muted-foreground">
          {list.length} {list.length === 1 ? 'tratamiento' : 'tratamientos'}
        </p>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((treatment) => (
            <TreatmentCard key={treatment.slug} treatment={treatment} />
          ))}
        </div>
      </div>
    </>
  )
}
