import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft, ArrowRight, Check, Clock, MessageCircle } from 'lucide-react'
import { TreatmentCard } from '@/components/site/treatment-card'
import { getContent, whatsappLink } from '@/lib/content'
import { cn } from '@/lib/utils'
import { btnOutline, btnPrimary, container } from '@/lib/ui'

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const content = await getContent()
  const treatment = content.treatments.find((t) => t.slug === slug)
  return treatment ? { title: treatment.name, description: treatment.description } : {}
}

export default async function TreatmentPage({ params }: Props) {
  const { slug } = await params
  const content = await getContent()
  const treatment = content.treatments.find((t) => t.slug === slug)
  if (!treatment) notFound()
  const related = content.treatments.filter((t) => t.category === treatment.category && t.slug !== slug).slice(0, 3)

  return (
    <>
      <section className={cn(container, 'grid gap-12 pb-20 pt-10 lg:grid-cols-2 lg:pt-14')}>
        <div className="flex flex-col gap-6">
          <Link href="/tratamientos" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-accent">
            <ArrowLeft className="size-4" aria-hidden="true" />
            Todos los tratamientos
          </Link>
          <p className="eyebrow">{treatment.category}</p>
          <h1 className="text-balance text-4xl md:text-6xl">{treatment.name}</h1>
          {treatment.badge && (
            <span className="self-start rounded-full bg-dark px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-dark-foreground">
              {treatment.badge}
            </span>
          )}
          <p className="text-pretty text-lg leading-relaxed text-muted-foreground">{treatment.description}</p>
          {treatment.benefits.length > 0 && (
            <div className="flex flex-col gap-4">
              <h2 className="text-2xl">Beneficios</h2>
              <ul className="flex flex-col gap-3">
                {treatment.benefits.map((b) => (
                  <li key={b} className="flex items-center gap-3">
                    <span className="flex size-6 items-center justify-center rounded-full bg-muted text-accent">
                      <Check className="size-3.5" aria-hidden="true" />
                    </span>
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <p className="rounded-2xl bg-muted p-5 text-sm leading-relaxed text-muted-foreground">
            Todos los tratamientos requieren valoración médica previa para confirmar que eres candidata(o) y diseñar el plan adecuado.
          </p>
          <dl className="flex gap-10 border-t border-border pt-6">
            <div>
              <dt className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Duración</dt>
              <dd className="mt-1 flex items-center gap-2 font-serif text-2xl">
                <Clock className="size-4 text-accent" aria-hidden="true" />
                {treatment.duration}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Inversión</dt>
              <dd className="mt-1 font-serif text-2xl">{treatment.price}</dd>
            </div>
          </dl>
          <div className="flex flex-wrap gap-3">
            <Link href={`/agendar?servicio=${treatment.slug}`} className={btnPrimary}>
              Agendar {treatment.name.length < 22 ? treatment.name : 'cita'}
              <ArrowRight className="size-4" aria-hidden="true" />
            </Link>
            <a
              href={whatsappLink(content, `Hola Dra. Nallely Mellado, quisiera información sobre ${treatment.name}`)}
              target="_blank"
              rel="noreferrer"
              className={btnOutline}
            >
              <MessageCircle className="size-4" aria-hidden="true" />
              Preguntar
            </a>
          </div>
        </div>
        <div className="relative aspect-[4/5] overflow-hidden rounded-4xl bg-muted lg:sticky lg:top-24 lg:self-start">
          {treatment.image && (
            <Image src={treatment.image || '/placeholder.svg'} alt={treatment.name} fill priority sizes="(min-width: 1024px) 50vw, 100vw" className="object-cover" />
          )}
        </div>
      </section>
      {related.length > 0 && (
        <section className="border-t border-border bg-card py-20">
          <div className={cn(container, 'flex flex-col gap-10')}>
            <h2 className="text-3xl md:text-4xl">También en {treatment.category}</h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((t) => (
                <TreatmentCard key={t.slug} treatment={t} />
              ))}
            </div>
          </div>
        </section>
      )}
    </>
  )
}
