import type { Metadata } from 'next'
import { ContactForm } from '@/components/site/contact-form'
import { Location } from '@/components/site/home/location'
import { PageIntro } from '@/components/site/page-intro'
import { getContent } from '@/lib/content'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'

export const metadata: Metadata = { title: 'Contacto' }

export default async function ContactPage() {
  const content = await getContent()
  return (
    <>
      <PageIntro eyebrow="Contacto" title="Hablemos de tu próximo tratamiento">
        <p>Déjanos tus datos y te contactamos, o escríbenos directo por WhatsApp.</p>
      </PageIntro>
      <div className={cn(container, 'max-w-3xl pb-4')}>
        <ContactForm whatsappNumber={content.contact.whatsapp} treatments={content.treatments.map((t) => t.name)} />
      </div>
      <Location content={content} />
    </>
  )
}
