import type { Metadata } from 'next'
import { AppointmentLookup } from '@/components/site/appointment-lookup'
import { PageIntro } from '@/components/site/page-intro'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'

export const metadata: Metadata = { title: 'Mi cita' }

export default function MyAppointmentPage() {
  return (
    <>
      <PageIntro eyebrow="Mi cita" title="Consulta o cancela tu cita">
        <p>Ingresa el folio que recibiste al agendar y el teléfono con el que te registraste.</p>
      </PageIntro>
      <div className={cn(container, 'max-w-3xl pb-24')}>
        <AppointmentLookup />
      </div>
    </>
  )
}
