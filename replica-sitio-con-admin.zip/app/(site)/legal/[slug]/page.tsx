import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { SimpleMarkdown } from '@/components/site/rich-text'
import { getContent } from '@/lib/content'
import { cn } from '@/lib/utils'
import { container } from '@/lib/ui'

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const page = (await getContent()).legal.find((p) => p.slug === slug)
  return page ? { title: page.title } : {}
}

export default async function LegalPage({ params }: Props) {
  const { slug } = await params
  const page = (await getContent()).legal.find((p) => p.slug === slug)
  if (!page) notFound()
  return (
    <article className={cn(container, 'flex max-w-3xl flex-col gap-6 pb-24 pt-14 md:pt-20')}>
      <p className="eyebrow">Legal</p>
      <h1 className="text-4xl md:text-5xl">{page.title}</h1>
      {page.intro && <p className="text-lg leading-relaxed text-muted-foreground">{page.intro}</p>}
      <SimpleMarkdown source={page.body} />
      {page.updated && <p className="border-t border-border pt-6 text-sm text-muted-foreground">Última actualización: {page.updated}.</p>}
    </article>
  )
}
